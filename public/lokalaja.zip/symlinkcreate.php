<?php
symlink('/home/bibitbun/laravel/storage/app/public', '/home/bibitbun/public_html/storage');